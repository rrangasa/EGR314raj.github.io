import serial, json, threading, webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler

COM  = 'COM8'
BAUD = 115200
PORT = 8080

state = {"pitch": 0.0, "roll": 0.0, "yaw": 0.0, "ok": False}
lock  = threading.Lock()

def reader():
    while True:
        try:
            with serial.Serial(COM, BAUD, timeout=2) as s:
                print(f"[serial] Connected to {COM}")
                with lock: state["ok"] = True
                while True:
                    line = s.readline().decode("utf-8", errors="ignore").strip()
                    try:
                        d = json.loads(line)
                        if "pitch" in d:
                            with lock: state.update(d)
                    except: pass
        except Exception as e:
            with lock: state["ok"] = False
            print(f"[serial] {e} — retrying...")
            import time; time.sleep(2)

HTML = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>IMU Orientation Dashboard</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r134/three.min.js"></script>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#c9d1d9;font-family:'Segoe UI',system-ui,sans-serif;padding:20px;min-height:100vh}
header{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}
h1{font-size:1.25rem;font-weight:700;color:#e6edf3}
.status{display:flex;align-items:center;gap:8px;font-size:.85rem;color:#8b949e}
.dot{width:10px;height:10px;border-radius:50%;background:#3fb950;animation:pulse 1.5s infinite}
.dot.off{background:#da3633;animation:none}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

.main-grid{display:grid;grid-template-columns:1.5fr 1fr;gap:16px;margin-bottom:16px}

.cube-card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:16px;
           display:flex;flex-direction:column;min-height:360px}
.cube-hdr{display:flex;justify-content:space-between;align-items:center;
          margin-bottom:10px;padding-bottom:10px;border-bottom:1px solid #30363d}
.cube-hdr h2{font-size:.88rem;font-weight:700;color:#e6edf3}
.cube-hdr span{font-size:.68rem;color:#8b949e}
canvas#cube3d{flex:1;width:100%;border-radius:8px;display:block}

.angles-card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:20px;
             display:flex;flex-direction:column;justify-content:space-around}
.angle-row{margin-bottom:18px}
.angle-row:last-child{margin-bottom:0}
.angle-label{font-size:.72rem;font-weight:700;letter-spacing:.08em;color:#8b949e;
             text-transform:uppercase;margin-bottom:6px;display:flex;justify-content:space-between}
.angle-label span{font-size:.68rem;color:#484f58;font-weight:400;letter-spacing:0}
.angle-value{font-size:2.4rem;font-weight:700;font-variant-numeric:tabular-nums;
             letter-spacing:-.02em;margin-bottom:8px}
.pitch-val{color:#58a6ff}
.roll-val {color:#3fb950}
.yaw-val  {color:#d29922}
.arc-track{width:100%;height:10px;background:#21262d;border-radius:5px;position:relative}
.arc-track::after{content:'';position:absolute;left:50%;top:-3px;
                  width:2px;height:16px;background:#30363d;border-radius:1px}
.arc-fill{position:absolute;top:0;height:100%;border-radius:5px;
          transition:width .08s ease,left .08s ease}

.chart-card{background:#161b22;border:1px solid #30363d;border-radius:12px;padding:16px}
.chart-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}
.chart-top h2{font-size:.75rem;color:#8b949e;text-transform:uppercase;letter-spacing:.08em}
.legend{display:flex;gap:16px;font-size:.72rem;color:#8b949e}
.li{display:flex;align-items:center;gap:5px}
.ld{width:14px;height:3px;border-radius:2px}
canvas#chart{display:block;width:100%;height:140px}
#hz{font-size:.68rem;color:#484f58;text-align:right;margin-top:5px}
</style>
</head>
<body>

<header>
  <h1>IMU Orientation — Complementary Filter (α=0.98)</h1>
  <div class="status"><div class="dot" id="dot"></div><span id="stxt">Connecting…</span></div>
</header>

<div class="main-grid">

  <div class="cube-card">
    <div class="cube-hdr">
      <h2>3D Orientation</h2>
      <span>Green = top &nbsp;|&nbsp; Axes: X=red Y=green Z=blue</span>
    </div>
    <canvas id="cube3d"></canvas>
  </div>

  <div class="angles-card">

    <div class="angle-row">
      <div class="angle-label">Pitch <span>nose up / down &nbsp;±90°</span></div>
      <div class="angle-value pitch-val" id="vPitch">0.00°</div>
      <div class="arc-track"><div class="arc-fill" id="bPitch"></div></div>
    </div>

    <div class="angle-row">
      <div class="angle-label">Roll <span>tilt left / right &nbsp;±180°</span></div>
      <div class="angle-value roll-val" id="vRoll">0.00°</div>
      <div class="arc-track"><div class="arc-fill" id="bRoll"></div></div>
    </div>

    <div class="angle-row">
      <div class="angle-label">Yaw <span>heading &nbsp;±180° &nbsp;(gyro only)</span></div>
      <div class="angle-value yaw-val" id="vYaw">0.00°</div>
      <div class="arc-track"><div class="arc-fill" id="bYaw"></div></div>
    </div>

  </div>
</div>

<div class="chart-card">
  <div class="chart-top">
    <h2>Angle History</h2>
    <div class="legend">
      <div class="li"><div class="ld" style="background:#58a6ff"></div>Pitch</div>
      <div class="li"><div class="ld" style="background:#3fb950"></div>Roll</div>
      <div class="li"><div class="ld" style="background:#d29922"></div>Yaw</div>
    </div>
  </div>
  <canvas id="chart"></canvas>
  <div id="hz">-- Hz</div>
</div>

<script>
// ── Three.js ──────────────────────────────────────────────────────
const cubeCanvas = document.getElementById('cube3d');
const scene    = new THREE.Scene();
scene.background = new THREE.Color(0x0d1117);
scene.fog = new THREE.Fog(0x0d1117, 10, 22);

const camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
camera.position.set(0, 2.5, 5.5);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({canvas: cubeCanvas, antialias: true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

const geo  = new THREE.BoxGeometry(3.2, 0.16, 2.0);
const mats = [
    new THREE.MeshPhongMaterial({color:0x1a4f72}),
    new THREE.MeshPhongMaterial({color:0x1a4f72}),
    new THREE.MeshPhongMaterial({color:0x1e8449, shininess:90}), // green top
    new THREE.MeshPhongMaterial({color:0x0d1117}),
    new THREE.MeshPhongMaterial({color:0x21618c}),
    new THREE.MeshPhongMaterial({color:0x21618c}),
];
const board = new THREE.Mesh(geo, mats);
scene.add(board);
board.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo),
          new THREE.LineBasicMaterial({color:0xffd700})));
board.add(new THREE.AxesHelper(1.4));

const grid = new THREE.GridHelper(12, 12, 0x21262d, 0x161b22);
grid.position.y = -1.5;
scene.add(grid);

scene.add(new THREE.AmbientLight(0xffffff, 0.5));
const sun = new THREE.DirectionalLight(0xffffff, 0.9);
sun.position.set(4, 7, 5); scene.add(sun);
const fill = new THREE.DirectionalLight(0x4488ff, 0.3);
fill.position.set(-4, -2, -4); scene.add(fill);

function resize3d(){
    const w=cubeCanvas.clientWidth, h=cubeCanvas.clientHeight||300;
    renderer.setSize(w,h,false);
    camera.aspect=w/h; camera.updateProjectionMatrix();
}
(function render3d(){ resize3d(); renderer.render(scene,camera); requestAnimationFrame(render3d); })();

// ── Bar helper ────────────────────────────────────────────────────
function setBar(id, val, maxVal, col){
    const el = document.getElementById(id);
    const p  = Math.min(Math.abs(val)/maxVal, 1) * 50;
    if(val >= 0){ el.style.left='50%'; el.style.right=''; }
    else        { el.style.right='50%'; el.style.left=''; }
    el.style.width = p + '%';
    el.style.background = val >= 0 ? col : col + '99';
}

// ── Chart ─────────────────────────────────────────────────────────
const N=150, hist={p:[],r:[],y:[]};
(function drawChart(){
    const cv=document.getElementById('chart');
    const W=cv.width=cv.offsetWidth, H=cv.height=140;
    const ctx=cv.getContext('2d');
    ctx.clearRect(0,0,W,H);
    ctx.strokeStyle='#21262d'; ctx.lineWidth=1;
    [.25,.5,.75].forEach(f=>{ctx.beginPath();ctx.moveTo(0,f*H);ctx.lineTo(W,f*H);ctx.stroke()});
    ctx.strokeStyle='#30363d'; ctx.lineWidth=1.5;
    ctx.beginPath();ctx.moveTo(0,H/2);ctx.lineTo(W,H/2);ctx.stroke();
    const MAX=180;
    function line(data,col){
        if(data.length<2) return;
        ctx.strokeStyle=col; ctx.lineWidth=2; ctx.lineJoin='round'; ctx.beginPath();
        data.forEach((v,i)=>{
            const x=(i/(N-1))*W, y=H/2-(v/MAX)*(H/2-5);
            i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
        });
        ctx.stroke();
    }
    line(hist.p,'#58a6ff');
    line(hist.r,'#3fb950');
    line(hist.y,'#d29922');
    requestAnimationFrame(drawChart);
})();

// ── Poll ──────────────────────────────────────────────────────────
let fc=0, lt=Date.now();

async function poll(){
    try{
        const d = await fetch('/data').then(r=>r.json());

        document.getElementById('dot').className   = d.ok ? 'dot' : 'dot off';
        document.getElementById('stxt').textContent = d.ok ? 'Live' : 'Disconnected';

        const fmt = v => (v>=0?'+':'')+v.toFixed(2)+'°';
        document.getElementById('vPitch').textContent = fmt(d.pitch);
        document.getElementById('vRoll').textContent  = fmt(d.roll);
        document.getElementById('vYaw').textContent   = fmt(d.yaw);

        setBar('bPitch', d.pitch,  90, '#58a6ff');
        setBar('bRoll',  d.roll,  180, '#3fb950');
        setBar('bYaw',   d.yaw,   180, '#d29922');

        // Cube — angles come pre-filtered from ESP32, just apply directly
        const DEG = Math.PI / 180;
        board.rotation.x =  d.pitch * DEG;
        board.rotation.z =  d.roll  * DEG;
        board.rotation.y = -d.yaw   * DEG;

        hist.p.push(d.pitch); if(hist.p.length>N) hist.p.shift();
        hist.r.push(d.roll);  if(hist.r.length>N) hist.r.shift();
        hist.y.push(d.yaw);   if(hist.y.length>N) hist.y.shift();

        fc++;
        const now=Date.now();
        if(now-lt>=1000){
            document.getElementById('hz').textContent=fc+' Hz';
            fc=0; lt=now;
        }
    }catch(e){}
    setTimeout(poll, 50);
}
poll();
</script>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def do_GET(self):
        if self.path == '/':
            body = HTML.encode()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html')
            self.send_header('Content-Length', len(body))
            self.end_headers(); self.wfile.write(body)
        elif self.path == '/data':
            with lock: body = json.dumps(state).encode()
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', len(body))
            self.end_headers(); self.wfile.write(body)

threading.Thread(target=reader, daemon=True).start()
print(f"Dashboard → http://localhost:{PORT}  (Ctrl+C to stop)")
webbrowser.open(f'http://localhost:{PORT}')
HTTPServer(('', PORT), Handler).serve_forever()
