# team_config.py
# Team 305 EGR314 -- shared protocol constants
# This is the ONLY place where IDs, reserved bytes, and packet
# parameters are defined. Do not duplicate these anywhere else.

# ── packet framing ───────────────────────────────────────────
PKT_LEN = 64
PREFIX  = (0xA5, 0x5A)
SUFFIX  = (0x59, 0x42)

# ── team-wide reserved bytes (prefix + suffix bytes) ─────────
# Every node stuffs these out of the payload window.
RESERVED_TEAM = (0xA5, 0x5A, 0x59, 0x42)

# ── per-node reserved bytes ──────────────────────────────────
# Each node may have one additional reserved byte personal to
# their payload patterns. Fill in as confirmed from each node's code.
# Set to None if that node has no additional reserved byte.
RESERVED_NODE = {
    0x43: None,   # Christo  -- uses team reserved only
    0x4C: None,   # Liam     -- TBD
    0x49: None,   # Isaiah   -- TBD
    0x41: None,   # Arianna  -- TBD
    0x4D: None,   # Myles    -- TBD
    0x52: None,   # Ragul    -- TBD
    0x44: None,   # Damian   -- TBD
}

def reserved_bytes_for(node_id):
    """Return the full tuple of reserved bytes for a given node."""
    extra = RESERVED_NODE.get(node_id)
    if extra is not None:
        return RESERVED_TEAM + (extra,)
    return RESERVED_TEAM

# ── node IDs ─────────────────────────────────────────────────
MY_ID      = 0x52   # <-- Ragul (Gyro)
LIAM_ID    = 0x4C
ISAIAH_ID  = 0x49
ARIANNA_ID = 0x41
MYLES_ID   = 0x4D
RAGUL_ID   = 0x52
DAMIAN_ID  = 0x44
BCAST      = 0x58

KNOWN_IDS  = (0x43, LIAM_ID, ISAIAH_ID, ARIANNA_ID, MYLES_ID, RAGUL_ID, DAMIAN_ID, BCAST)

# ── UART settings ─────────────────────────────────────────────
BAUD_RATE = 9600

# ── Request message type ──────────────────────────────────────
# HMI sends type 0x14 to request data on demand
# payload byte = the msg_type the requester wants back
MSG_REQUEST = 0x14

# ── WiFi (not used on this node) ─────────────────────────────
WIFI_NETWORKS = []
