# Ragul — Gyro subsystem — Node 0x52
# Team 305 EGR314

import uasyncio as asyncio
import struct, time, math
from machine import Pin, I2C, UART

from team_config import *
from uart_protocol import build_packet, build_ack, route_packet, UARTReceiver

# ── I2C / LSM9DS1 sensor setup ──────────────────────────────────
i2c = I2C(0, scl=Pin(10), sda=Pin(12), freq=400000)

AG_ADDR  = 0x6B
MAG_ADDR = 0x1E

GYRO_SENS  = 0.00875   # dps per LSB (±245 dps range)
ACCEL_SENS = 0.000061  # g per LSB (±2g range)

def wr(addr, reg, val): i2c.writeto_mem(addr, reg, bytes([val]))
def rxyz(addr, reg):
    return struct.unpack('<hhh', i2c.readfrom_mem(addr, reg, 6))

def init():
    wr(AG_ADDR, 0x22, 0x04)
    wr(AG_ADDR, 0x10, 0xC0)
    wr(AG_ADDR, 0x1E, 0x38)
    wr(AG_ADDR, 0x1F, 0x38)
    wr(AG_ADDR, 0x20, 0xC0)
    wr(MAG_ADDR, 0x20, 0xFC)
    wr(MAG_ADDR, 0x21, 0x00)
    wr(MAG_ADDR, 0x22, 0x00)
    wr(MAG_ADDR, 0x23, 0x0C)

init()

# ── Complementary filter (accel + gyro fusion) ─────────────────
# Combines gyro (fast, drifts) with accel (noisy, no drift).
# High-pass on gyro, low-pass on accel.
# angle = α × (prev + gyro×dt) + (1-α) × accel_angle

class ComplementaryFilter:
    def __init__(self, alpha=0.97):
        self.alpha = alpha
        self.roll  = 0.0   # degrees
        self.pitch = 0.0   # degrees
        self.yaw   = 0.0   # degrees (gyro-only, no mag)
        self.prev_time = time.ticks_ms()
        self.first = True

    def update(self, gx_dps, gy_dps, gz_dps, ax_g, ay_g, az_g):
        now = time.ticks_ms()
        dt = time.ticks_diff(now, self.prev_time) / 1000.0
        self.prev_time = now
        if dt > 0.5 or dt <= 0:
            dt = 0.01

        # Accel-based angles from gravity vector
        accel_roll  = math.atan2(ay_g, az_g) * 57.2958
        accel_pitch = math.atan2(-ax_g, math.sqrt(ay_g * ay_g + az_g * az_g)) * 57.2958

        if self.first:
            self.roll  = accel_roll
            self.pitch = accel_pitch
            self.first = False
        else:
            # Gyro integration
            gyro_roll  = self.roll  + gx_dps * dt
            gyro_pitch = self.pitch + gy_dps * dt
            # Complementary fusion
            self.roll  = self.alpha * gyro_roll  + (1 - self.alpha) * accel_roll
            self.pitch = self.alpha * gyro_pitch + (1 - self.alpha) * accel_pitch

        # Yaw: gyro integration only (needs magnetometer for correction)
        self.yaw += gz_dps * dt
        if self.yaw > 360:   self.yaw -= 720
        elif self.yaw < -360: self.yaw += 720

        return self.roll, self.pitch, self.yaw

    def reset(self):
        """Zero all angles and re-initialize from accel on next update."""
        self.roll  = 0.0
        self.pitch = 0.0
        self.yaw   = 0.0
        self.first = True

# ── Startup gyro bias calibration (keep sensor still!) ──────────
print('Calibrating gyro bias... keep sensor still')
_bias = [0, 0, 0]
for _ in range(100):
    gx, gy, gz = rxyz(AG_ADDR, 0x18)
    _bias[0] += gx; _bias[1] += gy; _bias[2] += gz
    time.sleep_ms(5)
_bias = [b // 100 for b in _bias]
print('Bias: gx={} gy={} gz={}'.format(_bias[0], _bias[1], _bias[2]))

imu = ComplementaryFilter(alpha=0.97)

# ── UART setup ────────────────────────────────────────────────
uart = UART(1, baudrate=BAUD_RATE, tx=Pin(44), rx=Pin(43))
uart_rx = UARTReceiver()

led_tx = Pin(40, Pin.OUT, value=0)
led_rx = Pin(41, Pin.OUT, value=0)

# ── Debug button (GPIO 8) ─────────────────────────────────────
btn_debug = Pin(8, Pin.IN, Pin.PULL_UP)
_btn_prev = 1

def check_debug_button():
    global _btn_prev
    cur = btn_debug.value()
    if _btn_prev == 1 and cur == 0:
        imu.reset()
        print('[ZERO] filter reset')
        roll, pitch, yaw = read_orientation()
        data = struct.pack('<hhh', roll, pitch, yaw)
        pkt = build_packet(DAMIAN_ID, 0x04, data)
        if pkt:
            print('[DBG] sending gyro roll={} pitch={} yaw={}'.format(roll, pitch, yaw))
            led_tx.value(1)
            uart.write(pkt)
            led_tx.value(0)
    _btn_prev = cur

# ── UART helpers ──────────────────────────────────────────────
def _forward(pkt):
    led_tx.value(1)
    uart.write(pkt)
    led_tx.value(0)

def _do_send_ack(dest, msg_type):
    if msg_type == 0xAA:
        return  # don't ACK an ACK
    pkt = build_ack(dest, msg_type)
    if pkt:
        uart.write(pkt)

def _handle_msg(msg_type, payload, sender):
    # handle on-demand data requests from HMI
    if msg_type == MSG_REQUEST and len(payload) >= 1:
        requested = payload[0]
        if requested == 0x04:
            # HMI wants gyro data right now
            roll, pitch, yaw = read_orientation()
            data = struct.pack('<hhh', roll, pitch, yaw)
            pkt = build_packet(sender, 0x04, data)
            if pkt:
                print('[REQ] sending gyro to 0x{:02X}'.format(sender))
                led_tx.value(1)
                uart.write(pkt)
                led_tx.value(0)

# ── Sensor reading + fusion ────────────────────────────────────
def read_orientation():
    """Read gyro + accel, apply complementary filter. Returns (roll, pitch, yaw) as int16 degrees."""
    gx, gy, gz = rxyz(AG_ADDR, 0x18)
    ax, ay, az = rxyz(AG_ADDR, 0x28)
    # Remove gyro bias, convert to physical units
    gx_dps = (gx - _bias[0]) * GYRO_SENS
    gy_dps = (gy - _bias[1]) * GYRO_SENS
    gz_dps = (gz - _bias[2]) * GYRO_SENS
    ax_g   = ax * ACCEL_SENS
    ay_g   = ay * ACCEL_SENS
    az_g   = az * ACCEL_SENS
    # Fuse
    roll, pitch, yaw = imu.update(gx_dps, gy_dps, gz_dps, ax_g, ay_g, az_g)
    # Clamp to int16 range
    def i16(v): return max(-9999, min(9999, int(round(v))))
    return i16(roll), i16(pitch), i16(yaw)

# ── Async tasks ───────────────────────────────────────────────
async def uart_task():
    while True:
        for raw_pkt in uart_rx.feed(uart):
            led_rx.value(1)
            route_packet(raw_pkt, _handle_msg, _do_send_ack, _forward)
            led_rx.value(0)
        await asyncio.sleep_ms(5)

async def main():
    print('Gyro node 0x52 ready — complementary filter active')
    asyncio.create_task(uart_task())
    while True:
        check_debug_button()
        await asyncio.sleep_ms(20)

try:
    asyncio.run(main())
finally:
    asyncio.new_event_loop()
