# uart_protocol.py
# Team 305 EGR314 -- UART protocol layer v4.0
# MicroPython / ESP32-S3
# Import into main.py. No sensor, display, or motor logic here.

import struct
from team_config import (
    MY_ID, BCAST, KNOWN_IDS,
    PKT_LEN, PREFIX, SUFFIX,
    reserved_bytes_for
)

# ── reserved bytes for this node ─────────────────────────────
_RESERVED = reserved_bytes_for(MY_ID)

# ── receiver states ───────────────────────────────────────────
_ST_WAIT_P1 = 0   # waiting for start bit 1: 0xA5
_ST_WAIT_P2 = 1   # waiting for start bit 2: 0x5A
_ST_COLLECT = 2   # accumulating 64 bytes

# ── error printer ─────────────────────────────────────────────
def _err(code, msg, raw=None):
    if raw:
        snippet = ' '.join('{:02X}'.format(b) for b in raw[:8])
        print('[ERR {}] {} -- raw: {}'.format(code, msg, snippet))
    else:
        print('[ERR {}] {}'.format(code, msg))

# ── packet builder ────────────────────────────────────────────
def build_packet(receiver_id, msg_type, data_bytes=b''):
    if receiver_id == 0x00:
        _err('E08', 'receiver ID is 0x00 (unset)')
        return None
    if receiver_id not in KNOWN_IDS:
        _err('E05', 'unknown receiver 0x{:02X}'.format(receiver_id))
        return None
    if len(data_bytes) > 57:
        _err('E07', 'payload too long: {} bytes'.format(len(data_bytes)))
        return None

    pkt = bytearray(PKT_LEN)
    pkt[0] = PREFIX[0]   # start bit 1
    pkt[1] = PREFIX[1]   # start bit 2
    pkt[2] = MY_ID        # sender ID
    pkt[3] = receiver_id  # receiver ID
    pkt[4] = msg_type
    for i, b in enumerate(data_bytes):
        if 5 + i >= 62:
            break
        pkt[5 + i] = b

    # byte stuffing -- subtract 1 from any reserved byte in payload window
    for i in range(4, 62):
        if pkt[i] in _RESERVED:
            pkt[i] = (pkt[i] - 1) & 0xFF

    pkt[62] = SUFFIX[0]   # stop bit 1
    pkt[63] = SUFFIX[1]   # stop bit 2
    return pkt

# ── packet validator ──────────────────────────────────────────
def validate_packet(pkt):
    """Run after collecting exactly 64 bytes. Returns True if packet is good."""
    if len(pkt) != PKT_LEN:
        _err('E03', 'bad length: {}'.format(len(pkt)), pkt)
        return False
    if pkt[0] != PREFIX[0] or pkt[1] != PREFIX[1]:
        _err('E01', 'missing start bits', pkt)
        return False
    if pkt[62] != SUFFIX[0] or pkt[63] != SUFFIX[1]:
        _err('E02', 'missing stop bits', pkt)
        return False
    sender   = pkt[2]
    receiver = pkt[3]
    if sender == 0x00 or receiver == 0x00:
        _err('E08', 'zero ID sender=0x{:02X} receiver=0x{:02X}'.format(
            sender, receiver), pkt)
        return False
    if sender not in KNOWN_IDS:
        _err('E04', 'sender ID not in loop: 0x{:02X}'.format(sender), pkt)
        return False
    if receiver not in KNOWN_IDS:
        _err('E05', 'receiver ID not in loop: 0x{:02X}'.format(receiver), pkt)
        return False
    if sender == MY_ID:
        _err('E09', 'loopback -- discarding own packet', pkt)
        return False
    return True

# ── router ────────────────────────────────────────────────────
def route_packet(pkt, handle_fn, send_ack_fn, forward_fn):
    """
    Call for every validated 64-byte packet. Implements the ROUTE step.

    handle_fn(msg_type, payload, sender)  -- subsystem message handler
    send_ack_fn(dest, msg_type)           -- sends ACK back to sender
    forward_fn(pkt)                       -- writes raw packet to UART TX
    """
    sender   = pkt[2]
    receiver = pkt[3]
    msg_type = pkt[4]
    payload  = bytes(pkt[5:62])

    if receiver == MY_ID:
        # packet is for me: handle it, send ACK, do NOT forward
        handle_fn(msg_type, payload, sender)
        send_ack_fn(sender, msg_type)

    elif receiver == BCAST:
        # broadcast (everyone 0x58): handle AND forward
        handle_fn(msg_type, payload, sender)
        forward_fn(pkt)

    else:
        # packet for someone else: forward only, do NOT handle
        forward_fn(pkt)

# ── ACK builder ───────────────────────────────────────────────
def build_ack(dest, received_type):
    return build_packet(dest, 0xAA, bytes([received_type]))

# ── UART receiver (state machine) ────────────────────────────
class UARTReceiver:
    """
    Implements the canonical receive state machine.
    WAIT_P1 -> WAIT_P2 -> COLLECT -> validate -> route

    Call feed(uart) every iteration of your async uart_task.
    Always call feed() before sending anything -- RX has priority over TX.
    """
    def __init__(self):
        self._state     = _ST_WAIT_P1
        self._buf       = bytearray(PKT_LEN)
        self._idx       = 0
        self.rx_count   = 0
        self.drop_count = 0
        self.fwd_count  = 0

    def feed(self, uart):
        """
        Drain UART RX one byte at a time through the state machine.
        Returns list of validated raw packets (bytes) ready to route.
        """
        packets = []
        while uart.any():
            b = uart.read(1)
            if not b:
                break
            byte = b[0]

            # ── WAIT_P1: hunting for start bit 1 (0xA5) ──────────
            if self._state == _ST_WAIT_P1:
                if byte == PREFIX[0]:
                    self._state = _ST_WAIT_P2
                # else: junk byte, ignore and keep waiting

            # ── WAIT_P2: confirm start bit 2 (0x5A) ──────────────
            elif self._state == _ST_WAIT_P2:
                if byte == PREFIX[1]:
                    # valid start -- begin collecting
                    self._buf = bytearray(PKT_LEN)
                    self._buf[0] = PREFIX[0]
                    self._buf[1] = PREFIX[1]
                    self._idx  = 2
                    self._state = _ST_COLLECT
                elif byte == PREFIX[0]:
                    pass   # 0xA5 again, stay in WAIT_P2
                else:
                    # false start -- back to hunting
                    self._state = _ST_WAIT_P1

            # ── COLLECT: accumulate until 64 bytes ────────────────
            elif self._state == _ST_COLLECT:
                self._buf[self._idx] = byte
                self._idx += 1
                if self._idx == PKT_LEN:
                    raw = bytes(self._buf)
                    self._state = _ST_WAIT_P1   # always reset state first
                    self._idx   = 0
                    if validate_packet(raw):
                        self.rx_count += 1
                        packets.append(raw)
                    else:
                        self.drop_count += 1

        return packets
