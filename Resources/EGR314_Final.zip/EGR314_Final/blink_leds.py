from machine import Pin
import time

leds = [Pin(39, Pin.OUT), Pin(40, Pin.OUT), Pin(41, Pin.OUT)]

while True:
    for led in leds:
        led.on()
        time.sleep(0.3)
        led.off()
    time.sleep(0.2)
