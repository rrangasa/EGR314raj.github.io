from machine import Pin, I2C
import time, struct, json, math

# ── I2C ──────────────────────────────────────────────────────────
i2c     = I2C(0, scl=Pin(10), sda=Pin(12), freq=400000)
AG_ADDR  = 0x6B
MAG_ADDR = 0x1E

def wr(addr, reg, val): i2c.writeto_mem(addr, reg, bytes([val]))
def rxyz(addr, reg):    return struct.unpack('<hhh', i2c.readfrom_mem(addr, reg, 6))

def init():
    wr(AG_ADDR,  0x22, 0x04)   # auto-increment
    wr(AG_ADDR,  0x10, 0xC0)   # gyro  952 Hz  ±245 dps
    wr(AG_ADDR,  0x1E, 0x38)   # gyro  XYZ on
    wr(AG_ADDR,  0x1F, 0x38)   # accel XYZ on
    wr(AG_ADDR,  0x20, 0xC0)   # accel 952 Hz  ±2 g
    wr(MAG_ADDR, 0x20, 0xFC)
    wr(MAG_ADDR, 0x21, 0x00)
    wr(MAG_ADDR, 0x22, 0x00)
    wr(MAG_ADDR, 0x23, 0x0C)

init()

# ── Button ────────────────────────────────────────────────────────
btn      = Pin(8, Pin.IN, Pin.PULL_UP)
btn_prev = 1

# ── Complementary filter state ────────────────────────────────────
ALPHA  = 0.98
pitch  = 0.0
roll   = 0.0
yaw    = 0.0
last_t = time.ticks_ms()

# Offsets — updated on button press to tare current orientation to zero
pitch_off = 0.0
roll_off  = 0.0
yaw_off   = 0.0

# Warm up: initialise pitch/roll from accel so there's no cold-start jump
ax, ay, az = [v * 0.000061 for v in rxyz(AG_ADDR, 0x28)]
pitch = math.atan2(-ax, math.sqrt(ay*ay + az*az)) * 57.2958
roll  = math.atan2(ay, az) * 57.2958

# ── Main loop ────────────────────────────────────────────────────
while True:
    now = time.ticks_ms()
    dt  = time.ticks_diff(now, last_t) / 1000.0
    last_t = now
    if dt <= 0 or dt > 0.5:
        time.sleep_ms(10)
        continue

    # ── Button: falling edge → tare all angles to zero ───────────
    btn_cur = btn.value()
    if btn_prev == 1 and btn_cur == 0:
        pitch_off = pitch
        roll_off  = roll
        yaw_off   = yaw
    btn_prev = btn_cur

    # Raw reads
    gx_r, gy_r, gz_r = rxyz(AG_ADDR, 0x18)
    ax_r, ay_r, az_r = rxyz(AG_ADDR, 0x28)

    # Scale
    gx = gx_r * 0.00875    # dps
    gy = gy_r * 0.00875
    gz = gz_r * 0.00875
    ax = ax_r * 0.000061   # g
    ay = ay_r * 0.000061
    az = az_r * 0.000061

    # Accel-derived tilt
    accel_pitch = math.atan2(-ax, math.sqrt(ay*ay + az*az)) * 57.2958
    accel_roll  = math.atan2(ay, az)                         * 57.2958

    # Complementary filter
    pitch = ALPHA * (pitch + gy * dt) + (1.0 - ALPHA) * accel_pitch
    roll  = ALPHA * (roll  + gx * dt) + (1.0 - ALPHA) * accel_roll
    yaw   = yaw + gz * dt

    # Keep yaw in -180 … +180
    if yaw >  180.0: yaw -= 360.0
    if yaw < -180.0: yaw += 360.0

    # Apply offsets (tare)
    out_pitch = pitch - pitch_off
    out_roll  = roll  - roll_off
    out_yaw   = yaw   - yaw_off

    # Keep tared yaw in -180 … +180
    if out_yaw >  180.0: out_yaw -= 360.0
    if out_yaw < -180.0: out_yaw += 360.0

    print(json.dumps({
        "pitch": round(out_pitch, 2),
        "roll":  round(out_roll,  2),
        "yaw":   round(out_yaw,   2)
    }))

    time.sleep_ms(20)   # 50 Hz
