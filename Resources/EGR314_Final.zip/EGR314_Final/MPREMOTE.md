# mpremote Quick Reference

All commands assume the ESP32 is on **COM8**. Change `COM8` to match your port.

---

## Upload a file to the ESP32

```bash
python -m mpremote connect COM8 cp <file.py> :<file.py>
```

**Examples:**
```bash
python -m mpremote connect COM8 cp main.py :main.py
python -m mpremote connect COM8 cp hmitest.py :hmitest.py
python -m mpremote connect COM8 cp comtest.py :comtest.py
```

---

## Upload and immediately reset (starts running)

```bash
python -m mpremote connect COM8 cp main.py :main.py + reset
```

---

## Run a file without uploading it

```bash
python -m mpremote connect COM8 run main.py
```

> Note: infinite loops will hold the connection. Use Ctrl+C to stop.

---

## List files on the ESP32

```bash
python -m mpremote connect COM8 ls
```

---

## Delete a file from the ESP32

```bash
python -m mpremote connect COM8 exec "import os; os.remove('file.py')"
```

---

## Run a one-liner on the ESP32

```bash
python -m mpremote connect COM8 exec "print('hello')"
```

---

## Open an interactive REPL

```bash
python -m mpremote connect COM8
```

Type MicroPython commands directly. Press **Ctrl+]** to exit.

---

## Soft reset the ESP32

```bash
python -m mpremote connect COM8 reset
```

---

## Chain multiple commands

Use `+` to chain commands in one call:

```bash
python -m mpremote connect COM8 cp main.py :main.py + reset
```

---

## Files on this board

| File | Purpose |
|---|---|
| `main.py` | Reads LSM9DS1 IMU, streams JSON over USB for dashboard |
| `comtest.py` | UART loopback test — TX every 5s, prints all RX bytes |
| `hmitest.py` | Press GPIO8 button → sends pitch/roll/yaw to HMI board |
| `gyro_test.py` | Terminal live dashboard (ANSI) for IMU data |

---

## Dashboard (runs on PC, not ESP32)

```bash
python dashboard.py
```

Make sure `main.py` is running on the ESP32 first, then run this on your PC.
Browser opens automatically at `http://localhost:8080`.

---

## Common Issues

| Problem | Fix |
|---|---|
| `failed to access COM8` | Close PuTTY or dashboard.py first — only one program can use COM8 at a time |
| Nothing in PuTTY | Check baud rate is **115200**, press reset button on PCB |
| `No module named mpremote` | Run `pip install mpremote` |
